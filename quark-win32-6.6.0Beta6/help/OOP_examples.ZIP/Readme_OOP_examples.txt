OOP_examples.zip

These files need to be copied to your Quark/plugins folder to work.