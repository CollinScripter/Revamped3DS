import math

class Circle:
    def __init__(self, x, y, z, r):
        self.x = x
        self.y = y
        self.z = z
        self.radius = r
        
    def circumference(self):
        return self.radius*math.pi
        
    def radius(self):
        return self.radius
