import math

class Figure:
    def __init__(self, x, y ,z):
        self.x = x
        self.y = y
        self.z = z
        
    def origin(self):
        return self.x, self.y, self.z

class Point(Figure):
    pass

class Circle(Figure):
    def __init__(x, y, z, r):
        Figure.__init__(self, x, y, z)
        self.radius = r
        
    def circumference(self):
        return self.radius*math.pi
        
    def radius(self):
        return self.radius
