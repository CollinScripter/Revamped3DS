import quarkpy.qmacro   # to bring in qmacro functions we need
import quarkx           # to bring in quarkx functions we need
from circles import *   # to bring in all of our circle class

def printcir(self):
    circle = Circle(1,0,3,1.5)  # assigns values to the attributes
    circle.circumference()      # passes the values to circle class
    answer = circle.circumference()  # collects the 'return' data
    print answer                # prints the answer to the console

def WindowClick(self):
    import quarkpy.mapoptions   # brings in the 'Options' menu
    printcir(self)              # calls our function
    quarkx.console(1)           # brings the console into view

quarkpy.mapoptions.items.append(quarkpy.qmenu.item("&Print Cir.", 
WindowClick)) # adds it to the 'Options' menu