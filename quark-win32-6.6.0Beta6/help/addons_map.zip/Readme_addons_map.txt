addons_map.zip

This is the default map file for the Addons menu import function.

It is a Quake2 map format and needs to be placed in your Quake2\tmpQuArK\maps folder.

If you are not mapping for Quake2, create a simple map file for the game you are mapping for, with ONLY world_spawn and save it as 1SaveImport.map then place is in your tmpQuArK\maps folder.

cdunde