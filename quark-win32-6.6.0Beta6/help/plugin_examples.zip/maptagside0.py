
Info = {
   "plug-in":       "Side Tag & Glue",
   "desc":          "Basic Side tagging and gluing to tagged side",
   "date":          "1999",
   "author":        "tiglari",
   "author e-mail": "tiglari@hexenworld.net",
   "quark":         "Version 6" }


import quarkx
import quarkpy.mapmenus
import quarkpy.mapentities
import quarkpy.qmenu
import quarkpy.mapeditor
import quarkpy.mapcommands
from quarkpy.maputils import *

def tagSideClick(m):
    quarkx.msgbox("This command does nothing", MT_INFORMATION, MB_OK)

quarkpy.mapcommands.items.append(quarkpy.qmenu.item("&Do Nothing", tagSideClick))

